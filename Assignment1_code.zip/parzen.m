function y = parzen(x, T, h)
n = length(T);
y = (1/n) * sum(1/h * 1/(sqrt(2*pi))*exp(-((x-T)/h).^2)/2);
end