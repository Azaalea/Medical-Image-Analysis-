close all; clear;
% generate data
train0 = normrnd(0,0.4,10,1);
test0 = normrnd(0,0.4,1000,1);
train1 = normrnd(1,0.4,10,1);
test1 = normrnd(1,0.4,1000,1);
train0_wide = normrnd(0,4,10,1);
test0_wide = normrnd(0,4,1000,1);
train1_wide = normrnd(1,4,10,1);
test1_wide = normrnd(1,4,1000,1);
% non-parametric parzen window estimation
x_plot = [-1.5:.01:2.5];
x_plot_w = [-15:.01:15];
g0 = zeros(size(x_plot_w));
g1 = zeros(size(x_plot_w));
g0w = zeros(size(x_plot_w));
g1w = zeros(size(x_plot_w));
h=1;
% calculate parzens
for i=1:length(x_plot_w)
g0(i) = parzen(x_plot_w(i),train0_wide,h);
g1(i) = parzen(x_plot_w(i),train1_wide,h);
end
for i=1:length(x_plot_w)
g0w(i) = parzen(x_plot_w(i),train0_wide,h);
g1w(i) = parzen(x_plot_w(i),train1_wide,h);
end
% Standard deviation = 0.4
% p1 = plot(x_plot,g0, 'LineWidth', 2);
% hold on
% p2 = plot(x_plot,normpdf(x_plot,0,0.4), 'LineWidth', 2);
% hold on
% p3 = plot(x_plot,g1, 'LineWidth', 2);
% hold on
% p4 = plot(x_plot,normpdf(x_plot,1,0.4), 'LineWidth', 2);
% hold on
% p5 = plot(train0,zeros(length(train0),1), 'o','MarkerSize',4, 'LineWidth', 2);
% hold on
% 
% p6 = plot(train1,zeros(length(train1),1), 'o','MarkerSize',4, 'LineWidth', 2);
% legend("Parzen Class 1","True Model Class 1","Parzen Class 2","True Model Class 2","Train Data Class 1","Train Data Class 2");
% title("Parzen Windows for h=0.02 and std= 0.4");
% hold off

% Standard deviation = 4
p1 = plot(x_plot_w,g0w, 'LineWidth', 2);
hold on
p2 = plot(x_plot_w,normpdf(x_plot_w,0,4), 'LineWidth', 2);
hold on
p3 = plot(x_plot_w,g1w,'LineWidth', 2);
hold on
p4 = plot(x_plot_w,normpdf(x_plot_w,1,4),'LineWidth', 2);
hold on
p5 = plot(train0_wide,zeros(length(train0_wide),1), 'o','MarkerSize',4, 'LineWidth', 2);
hold on
p6 = plot(train1_wide,zeros(length(train1_wide),1), 'o','MarkerSize', 4, 'LineWidth', 2);
legend("Parzen Class 1","True Model Class 1","Parzen Class 2",'True Model Class 2',"Train Data Class 1","Train Data Class 2");
title("Parzen Windows for h= 0.02 and std=4");
hold off
% calculate conditional probabilities
% y0 = normpdf(x_plot,0,0.4)./ (normpdf(x_plot,0,0.4) + normpdf(x_plot,1,0.4));
% y1 = normpdf(x_plot,1,0.4)./ (normpdf(x_plot,0,0.4) + normpdf(x_plot,1,0.4));
% y0parzen = g0 ./ (g0+g1);
% y1parzen = g1 ./ (g0+g1);
% y0_w = normpdf(x_plot_w,0,4)./ (normpdf(x_plot_w,0,4) + normpdf(x_plot_w,1,4));
% y1_w = normpdf(x_plot_w,1,4)./ (normpdf(x_plot_w,0,4) + normpdf(x_plot_w,1,4));
% y0parzen_w = g0w ./ (g0w+g1w);
% y1parzen_w = g1w ./ (g0w+g1w);
% plot(x_plot,y0);
% hold on
% plot(x_plot,y1);
% hold on
% plot(x_plot,y0parzen);
% hold on
% plot(x_plot,y1parzen);
% legend("p(y=1|x), true model","p(y=2|x), true model", "p(y=1|x), estimated
% model","p(y=2|x), estimated model");
% title("Conditional Probabilities for h=1 and std=0.04");
% hold off
% plot(x_plot_w,y0_w);
% hold on
% plot(x_plot_w,y1_w);
% hold on
% plot(x_plot_w,y0parzen_w);
% hold on
% plot(x_plot_w,y1parzen_w);
% legend("p(y=1|x), true model","p(y=2|x), true model", "p(y=1|x),
% estimated model","p(y=2|x), estimated model");
% title("Conditional Probabilities for h=0.02 and std=4");
% hold off
% calculate correct classification
pred_test0_true_model = 0;
pred_test1_true_model = 0;
pred_test0w_true_model = 0;
pred_test1w_true_model = 0;
pred_test0_estimated_model_small_h = 0;
pred_test1_estimated_model_small_h = 0;
pred_test0w_estimated_model_small_h = 0;
pred_test1w_estimated_model_small_h = 0;
pred_test0_estimated_model_large_h = 0;
pred_test1_estimated_model_large_h = 0;
pred_test0w_estimated_model_large_h = 0;
pred_test1w_estimated_model_large_h = 0;
for i=1:1000
% correct predictions of the true model
    if normpdf(test0(i),0,0.4)/(normpdf(test0(i),0,0.4)+normpdf(test0(i),1,0.4)) > 0.5
        pred_test0_true_model = pred_test0_true_model + 1;
    end
    if normpdf(test1(i),1,0.4)/(normpdf(test0(i),0,0.4)+normpdf(test0(i),1,0.4)) > 0.5
        pred_test1_true_model = pred_test1_true_model + 1;
    end
    if normpdf(test0_wide(i),0,4)/(normpdf(test0_wide(i),0,4)+normpdf(test0_wide(i),1,4)) > 0.5
        pred_test0w_true_model = pred_test0w_true_model + 1;
    end
    if normpdf(test1_wide(i),1,4)/(normpdf(test1_wide(i),0,4)+normpdf(test1_wide(i),1,4))> 0.5 
        pred_test1w_true_model = pred_test1w_true_model + 1;
    end
    % correct prediction of the estimated model
    if parzen(test0(i),train0,0.02) /(parzen(test0(i),train0,0.02)+parzen(test0(i),train1,0.02)) > 0.5
        pred_test0_estimated_model_small_h = pred_test0_estimated_model_small_h + 1;
    end
    if parzen(test1(i),train1,0.02) /(parzen(test1(i),train0,0.02)+parzen(test1(i),train1,0.02)) > 0.5
        pred_test1_estimated_model_small_h = pred_test1_estimated_model_small_h + 1;
    end
    if parzen(test0_wide(i),train0_wide,0.02) / (parzen(test0_wide(i),train0_wide,0.02)+parzen(test0_wide(i),train1_wide,0.02))> 0.5
        pred_test0w_estimated_model_small_h = pred_test0w_estimated_model_small_h + 1;
    end
    if parzen(test1_wide(i),train1_wide,0.02) /(parzen(test1_wide(i),train0_wide,0.02)+parzen(test1_wide(i),train1_wide,0.02))> 0.5
        pred_test1w_estimated_model_small_h = pred_test1w_estimated_model_small_h + 1;
    end
    if parzen(test0(i),train0,1) /(parzen(test0(i),train0,1)+parzen(test0(i),train1,1)) > 0.5 
        pred_test0_estimated_model_large_h = pred_test0_estimated_model_large_h + 1;
    end
    if parzen(test1(i),train1,1) /(parzen(test1(i),train0,1)+parzen(test1(i),train1,1)) > 0.5
        pred_test1_estimated_model_large_h = pred_test1_estimated_model_large_h + 1;
    end
    if parzen(test0_wide(i),train0_wide,1) / (parzen(test0_wide(i),train0_wide,1)+parzen(test0_wide(i),train1_wide,1))> 0.5
        pred_test0w_estimated_model_large_h = pred_test0w_estimated_model_large_h + 1;
    end
    if parzen(test1_wide(i),train1_wide,1) /(parzen(test1_wide(i),train0_wide,1)+parzen(test1_wide(i),train1_wide,1))> 0.5
        pred_test1w_estimated_model_large_h = pred_test1w_estimated_model_large_h + 1;
    end
end
% display correct classifications
disp(pred_test0_true_model);
disp(pred_test1_true_model);
disp(pred_test0w_true_model);
disp(pred_test1w_true_model);
disp(pred_test0_estimated_model_small_h);
disp(pred_test1_estimated_model_small_h);
disp(pred_test0w_estimated_model_small_h);
disp(pred_test1w_estimated_model_small_h);
disp(pred_test0_estimated_model_large_h);
disp(pred_test1_estimated_model_large_h);
disp(pred_test0w_estimated_model_large_h);
disp(pred_test1w_estimated_model_large_h);
% display error rates
err0true = (1000-pred_test0_true_model) / 1000
err1true = (1000-pred_test1_true_model) / 1000
err0true_w = (1000-pred_test0w_true_model) / 1000
err1true_w = (1000-pred_test1w_true_model) / 1000

err0estimated_small_h = (1000-pred_test0_estimated_model_small_h) / 1000
err1estimated_small_h = (1000-pred_test1_estimated_model_small_h) / 1000
err0estimated_w_small_h = (1000-pred_test0w_estimated_model_small_h) / 1000
err1estimated_w_small_h = (1000-pred_test1w_estimated_model_small_h) / 1000
err0estimated_large_h = (1000-pred_test0_estimated_model_large_h) / 1000
err1estimated_large_h = (1000-pred_test1_estimated_model_large_h) / 1000
err0estimated_w_large_h = (1000-pred_test0w_estimated_model_large_h) / 1000
err1estimated_w_large_h = (1000-pred_test1w_estimated_model_large_h) / 1000
% calculate the cumulative function until the optimal threshold
% this is theoretically the percentage of samples that will be
% classified correctly / percentage of samples classified wrongly
err_0_small_std = 1 - normcdf(0.5,0,0.4)
err_1_small_std = normcdf(0.5,1,0.4)
err_0_large_std = 1 - normcdf(0.5,0,4)
err_1_large_std = normcdf(0.5,1,4)

%% Find optimal h values
% generate data
train1_small_std = normrnd(0,0.4,10,1);
train2_small_std = normrnd(1,0.4,10,1);
train1_large_std = normrnd(0,4,10,1);
train2_large_std = normrnd(1,4,10,1);
% h-values
h_vals = [0.01:.01:8];
h_errors_small_std = zeros(length(h_vals));
h_errors_large_std = zeros(length(h_vals));
% iterate through all h values
for i=1:length(h_vals)
h = h_vals(i);
% store performance
p_s = 0;
p_l = 0;
for k=1:10
% get test data sample
test1_s = train1_small_std(k);
test2_s = train2_small_std(k);
test1_l = train1_large_std(k);
test2_l = train2_large_std(k);
% copy train data
train1_s = train1_small_std;
train2_s = train2_small_std;
train1_l = train1_large_std;
train2_l = train2_large_std;
% delete the test sample
train1_s(k) = [];
train2_s(k) = [];
train1_l(k) = [];
train2_l(k) = [];
% calculate probabilities from parzens
p1_s = parzen(test1_s,train1_s,h);
p2_s = parzen(test2_s,train2_s,h);
p1_l = parzen(test1_l,train1_l,h);
p2_l = parzen(test2_l,train2_l,h);
% calculate the sum of the logs of the probabilities for that h
p_s = p_s + log(p1_s) + log(p2_s);
p_l = p_l + log(p1_l) + log(p2_l);
end
h_errors_small_std(i) = p_s;
h_errors_large_std(i) = p_l;
end


