%% Code for part 1 of shape model project 
clc
clear
close all

% Load the DMSA images and manual segmentation
load dmsa_images
load man_seg

% Extract x- and y-coordinates
Xmcoord=real(man_seg);
Ymcoord=imag(man_seg);

% Choose patient and look at image
pat_nbr = 1;

figure
imagesc(dmsa_images(:,:,pat_nbr))
colormap(gray)
axis xy
axis equal
hold on
drawshape_comp(man_seg,[1 length(man_seg) 1],'.-r')


%%
boundary = [Xmcoord, Ymcoord];

% find the index of the lowest point of the boundary
[~, min_idx] = min(boundary(:,2));
% Descending order, make lowest point first in the list
new_boundary = circshift(boundary, length(boundary) - min_idx);

% Resampling
[x, y] = resampleLandmarks(new_boundary(:,1), new_boundary(:, 2));

figure;
plot(x, y, 'LineWidth', 2);

figure;
plot([x; x(1)], [y; y(1)], 'LineWidth', 2)
hold on
plot([Xmcoord; Xmcoord(1)], [Ymcoord; Ymcoord(1)], 'r-.','LineWidth', 2)
title('Resampling of man\_seg', 'FontSize', 20)

scatter(x, y, 'bo', 'filled')
scatter(Xmcoord, Ymcoord, 'ro', 'filled')
legend('Resample', 'Orignal', 'FontSize', 15)

%%
figure;
subplot(1,2,1)
imagesc(dmsa_images(:,:,pat_nbr))
colormap(gray)
%axis xy
xlim([0,128])
ylim([0,128])
% axis equal
hold on
drawshape_comp(man_seg,[1 length(man_seg) 1],'.-r')
title('Original man\_seg.mat', 'FontSize', 20)

subplot(1,2,2)
new_seg = complex(x,y);
imagesc(dmsa_images(:,:,pat_nbr))
colormap(gray)
xlim([0,128])
ylim([0,128])
% axis equal
hold on
drawshape_comp(new_seg,[1 length(new_seg) 1],'.-r')
title('Resampled of man\_seg.mat', 'FontSize', 20)


%% Code for part 2 of shape model project 

% Load the DMSA images
load dmsa_images

% Choose patient and look at image
pat_nbr = 1;

figure;
imagesc(dmsa_images(:,:,pat_nbr))
colormap(gray)
axis xy

% Load the manual segmentations
% Columns 1-20: the right kidney of patient 1-20
% Columns 21-40: the mirrored left kidney of patient 1-20
% Each row is a landmark position
load models

% Extract x- and y-coordinates
Xcoord=real(models);
Ycoord=imag(models);

% Mirror the left kidney to get it in the right position in the image
figure;
imagesc(dmsa_images(:,:,pat_nbr))
colormap(gray)
axis xy
hold on
drawshape_comp(models(:,pat_nbr),[1 14 1],'.-r')
drawshape_comp((size(dmsa_images,2)+1)-models(:,pat_nbr+20)',[1 14 1],'.-r')
axis equal


figure;
imagesc(dmsa_images(:,:,pat_nbr))
colormap(gray)
axis xy
hold on
drawshape_comp(models(:,pat_nbr),[1 14 1],'.-r')
hold on
drawshape_comp((size(dmsa_images,2)+1)-models(:,pat_nbr+20)',[1 14 1],'.-r')
axis equal

%% Resampling using linear interpolation
function [new_x, new_y]= resampleLandmarks(x, y)
% Extract x-and y-coordinates
pathXY = [x y; x(1) y(1)];
% Euclidean distance between the landmarks
d = sqrt(sum(diff(pathXY, [], 1).^2, 2));
% Add a starting point
stepLengths = [0; d];
% cumulative sum => curve length/lengths
cumLen = cumsum(stepLengths);
%% Linear interpolation
% Define the query points to be a finer sampling over the range of cumLen
finalStepLocs = linspace(0, cumLen(end), 15);
% samples cumLen, and corresponding samples pathXY
finalPath = interp1(cumLen, pathXY, finalStepLocs, 'linear');
finalPath = finalPath(1:14,:);

new_x = finalPath(:,1);
new_y = finalPath(:,2);
end