clc
clear
close all

% Load the DMSA images and manual segmentation
load dmsa_images
load man_seg
load models

%% 4. Align all shapes to the mean shape
[mean_shape, R, t, s] = alignment_algorithm(models);


%% plot the aligned shapes in the same figure before proceeding
 % with the shape model
 % 1. Perform similarity transformation on the models
 models_before_transformation = zeros(size(models));
 for i = 1:length(models)
     % apply transformation
     models_before_transformation(:,i) = apply_transformation(R{i}, t{i}, s{i}, models(:,i));
 end
 
 
 
 % 2. plot the aligned shapes in the same figure
 figure;
 % show the mean shape 
 x_mean = mean_shape(1,:);
 y_mean = mean_shape(2,:);
 plot(x_mean, y_mean, 'r-.', 'LineWidth', 2)
 hold on
 for i = 1:length(models_before_transformation)
     % Extract each model's coordinates, complex
     model_coords = models_before_transformation(:, i);
     x = real(model_coords);
     y = imag(model_coords);
     p = plot(x, y);
     p.Color(4) = 0.2;
 end
 legend('Mean shape', 'FontSize', 15)
 title('Aligned Shapes', 'FontSize', 18)
 
 %% Calculate covariance using covariance-function
C = covariance(mean_shape, models_before_transformation);
 
%% Calculate corresponding eigen-values and eigen-vectors
[evectors, evalues] = eig(C);


%% Plot the eigen-values
% Assume that the eigen-values are ordered decreasingly

evalues = flip(diag(evalues), 1);
figure;
scatter(1:28, evalues, 50, 'filled')
title('Eignvalues', 'FontSize', 18)

%% use the eignvectors as a new basis, N points with 2 coordinates each
 % The eigen-vector corresponding to the highest eigenvalue
 % describes the most likely variation in the training data.
P = flip(evectors, 2);
 
%% Visualization of the modes with different b's
for mode_idx = 1:14
    visualise(mean_shape, mode_idx, P, evalues)
end


%% How to select the number of modes
% 1. look at the geometric appearence of each mode;
% (Usually the first modes descibes the relevant variations in
% the training set and the last modes only capture noise in
% the training data)
% 2. Calculate energy in each shape
% Plot cumulative energy for eigenvalues
figure;
plot(0:28, [0;cumsum(evalues)/sum(evalues)], 'LineWidth', 3)
hold on
plot(0:28, 0.7*ones(1,29), 'm-.')
plot(0:28, 0.8*ones(1,29), 'c-.')
plot(0:28, 0.9*ones(1,29), 'g-.')
plot(0:28, 0.95*ones(1,29), 'r-.')
legend({'Cumulative Energy', '70%', '80%', '90%', '95%'}, 'FontSize', 14)
s1 = scatter(0:28, [0; cumsum(evalues)/sum(evalues)], 50, 'r', 'filled');
set(get(get(s1(1),'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
title('Cumulative Energy', 'FontSize', 18)

%% Visualisation:
% lambda = evalues
function [] = visualise(mean_shape, mode_idx, P, evalues)
evalue = evalues(mode_idx);
% N = 14
% [x1, x2,..., x_N, y1, y2,..., y_N]
mid = length(P)/2;
evec = [P(1:mid, mode_idx), P(mid+1:end, mode_idx)]';

% plot the usual cases
p1 = mean_shape - 2*sqrt(evalue)*evec;
p2 = mean_shape - sqrt(evalue)*evec;
p3 = mean_shape;
p4 = mean_shape  + sqrt(evalue)*evec;
p5 = mean_shape + 2*sqrt(evalue)*evec;

figure;
plot(p1(1,:), p1(2,:))
hold on 
plot(p2(1,:), p2(2,:))
% mean shape
plot(p3(1,:), p3(2,:), 'r-.', 'LineWidth', 3);
plot(p4(1,:), p4(2,:))
plot(p5(1,:), p5(2,:))
hold off
legend('Mean - 2*sqrt(lambda)', 'Mean - sqrt(lambda)', 'Mean', 'Mean + sqrt(lambda)', 'Mean + 2*sqrt(lambda)', 'FontSize', 10)
title(['Principal mode ' num2str(mode_idx)], 'FontSize', 18);
end

 %% Covariance matrix S, slide 10
  % 1. Calculate the difference with respect to the mean shape
  %    for each shape
function S = covariance(mean_shape, shapes)
shapes_xs = real(shapes);
shapes_ys = imag(shapes);
  
 % The mean shape (X_bar) = (x, y)
X_bar = [mean_shape(1, :)'; mean_shape(2, :)'];

[N, M] = size(shapes); % M: shape number, N: point number
% For calculation of (2N)x(2N) covariance matrix
S = zeros(2*N, 2*N);
for i =1:length(shapes)
  X = [shapes_xs(:, i); shapes_ys(:,i)];
  dX = X - X_bar;
  S = S + dX*dX';
end
S = S / M; 
end   



%% Function: Alignment
function [aligned_mean_shape, R_star, t_star, s_star] = alignment_algorithm(models)
%% 1. Align each shape to the first shape
    % 'aligned_mean_shape' is initialized as the first shape
aligned_mean_shape = [real(models(:,1)), imag(models(:,1))]';

for n =1:5
    % store first shapes' 14 landmarks in a 1x1 cell
    aligned_shapes{1} = aligned_mean_shape;
    % Align each shape to the first shape 'aligned_mean_shape'
    for i = 1:length(models)
        shape_to_align = [real(models(:,i)), imag(models(:,i))]';
        %similarity transformation: y = sRx + t
        [R_star{i}, t_star{i}, s_star{i}] = similarity_transform(shape_to_align, aligned_mean_shape);
        % store each transformed/aligned shape in a new cell
        aligned_shapes{i} = s_star{i}*R_star{i}*shape_to_align + t_star{i};
    end


%% 2. Calculate the mean of the transformed/aligned shapes
    % to store the coordinates of the aligned shapes
    mean_coords = zeros(2,14);
    for i = 1:length(aligned_shapes)
        mean_coords = mean_coords + aligned_shapes{i};
    end
    mean_shape = mean_coords/length(aligned_shapes);
    
    %% 3. Align the mean shape to the first
    [R, t, s] = similarity_transform(mean_shape, aligned_mean_shape);
    %% 5. Update the mean shape
    aligned_mean_shape = s*R*mean_shape + t;
    
    end   
end

%% Function: Similarity transformation
% only interested in the shape of a kidney.
% The first step is to remove the scale, translation 
% and rotation. Procrustes analysis is used to find
% similarity transform from x to y
function [R, t, s] = similarity_transform(x,y)
%  column vector containing the mean of each row
% of matrices x and y
avg_x = mean(x,2);
avg_y = mean(y,2);
x_tilde = x - avg_x;
y_tilde = y - avg_y;
[U, ~, V] = svd(y_tilde*x_tilde');
R = U*diag([1 det(U*V')])*V';
s = sum(diag(y_tilde'*R*x_tilde))/sum(vecnorm(x_tilde').^2);
t = avg_y - s*R*avg_x;
end

%% create a new function for step 4:
 function ys = apply_transformation(R, t, s, xs)
 % extract each model's cooridnates in a 2x40 matrix
 xs = [real(xs), imag(xs)]';
 % similarity transformation of models xs to ys
 ys = s*R*xs + t;
 % The new coordinates
 ys = complex(ys(1,:), ys(2,:));
 end
